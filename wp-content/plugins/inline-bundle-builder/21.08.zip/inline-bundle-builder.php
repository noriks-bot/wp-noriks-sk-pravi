<?php
/**
 * Plugin Name: Inline Bundle Builder
 * Description: Build a bundle in a responsive modal. Saves only Colors & Sizes as cart/order metadata (simple aggregation).
 * Version:     2.6.3
 * Author:      You
 */

if (!defined('ABSPATH')) exit;

class IBB_Plugin_SimpleMeta {

    public function __construct() {
        add_shortcode('inline_bundle_builder', [$this, 'shortcode']);
        add_action('wp_enqueue_scripts',       [$this, 'enqueue']);

        // AJAX: resolve variation from attributes (unchanged)
        add_action('wp_ajax_ibb_find_variation',        [$this, 'ajax_find_variation']);
        add_action('wp_ajax_nopriv_ibb_find_variation', [$this, 'ajax_find_variation']);

        // Save simple meta & display it
        add_filter('woocommerce_add_cart_item_data',              [$this, 'hook_add_cart_item_data'], 10, 3);
        add_filter('woocommerce_get_item_data',                   [$this, 'hook_display_item_data'],  10, 2);
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'hook_order_item_meta'],    10, 4);
    }

    /* -------------------------------------------------
     * Assets
     * ------------------------------------------------*/
    public function enqueue() {
        if (!is_product()) return;

        wp_register_style ('ibb-style', plugins_url('ibb.css?d34323333e333334j23234334a3n', __FILE__), [], '2.6.3');
        wp_register_script('ibb-script', plugins_url('ibb.js?d3ej342333233343334333a3n',  __FILE__), ['jquery'], '2.6.3', true);

        wp_enqueue_style ('ibb-style');
        wp_enqueue_script('ibb-script');
        wp_localize_script('ibb-script', 'IBB', [
            'ajax'  => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ibb'),
        ]);
    }

    /* -------------------------------------------------
     * Shortcode
     * ------------------------------------------------*/
    /**
     * [inline_bundle_builder products="504,505,506" slots="3"]
     */
    public function shortcode($atts) {
        if (!class_exists('WooCommerce')) return '';

        $a = shortcode_atts([
            'products' => '',
            'slots'    => 3,
        ], $atts);

        $ids   = array_filter(array_map('absint', explode(',', $a['products'])));
        $slots = max(1, absint($a['slots']));
        if (!$ids) return '<em>No products configured.</em>';

        // Build product cards for modal
        $cards = [];
        foreach ($ids as $pid) {
            $p = wc_get_product($pid);
            if (!$p || !$p->is_purchasable()) continue;

            $c = [
                'id'    => $pid,
                'type'  => $p->get_type(),
                'title' => $p->get_name(),
                'price' => $p->get_price_html(),
                'img'   => wp_get_attachment_image_url($p->get_image_id() ?: get_post_thumbnail_id($pid), 'woocommerce_single'),
                'attrs' => [],
            ];

            if ($p->is_type('variable')) {
                $vattrs = $p->get_variation_attributes();
                foreach ($vattrs as $tax_raw => $options) {
                    $tax_norm = str_replace('attribute_', '', $tax_raw);
                    if (strpos($tax_norm, 'pa_') === 0) $tax_norm = substr($tax_norm, 3);

                    $label = wc_attribute_label($tax_norm) ?: wc_attribute_label($tax_raw) ?: 'Option';
                    $opts  = [];
                    foreach ((array)$options as $opt) {
                        $term = taxonomy_exists($tax_norm) ? get_term_by('slug', $opt, $tax_norm) : null;
                        $opts[] = [
                            'value' => $term ? $term->slug : (string)$opt,
                            'label' => $term ? $term->name : (string)$opt,
                        ];
                    }
                    $c['attrs'][] = [
                        'raw'   => $tax_raw,
                        'norm'  => $tax_norm,
                        'label' => $label,
                        'opts'  => $opts,
                    ];
                }
            }

            $cards[] = $c;
        }

        // Prefill slots from POST if present
        $prefilled_raw = isset($_POST['ibb_cart_data']) ? wp_unslash($_POST['ibb_cart_data']) : '';
        $prefilled     = $prefilled_raw ? json_decode($prefilled_raw, true) : [];
        if (!is_array($prefilled)) $prefilled = [];

        // Helper to get prefilled product image/name
        $get_prefill_view = function($slot_index) use ($prefilled) {
            $out = [
                'filled' => false,
                'name'   => '',
                'img'    => '',
                'pid'    => 0,
            ];
            if (empty($prefilled[$slot_index]['product_id'])) return $out;

            $pid = absint($prefilled[$slot_index]['product_id']);
            $p   = $pid ? wc_get_product($pid) : null;
            if (!$p) return $out;

            $out['filled'] = true;
            $out['pid']    = $pid;
            $out['name']   = $p->get_name();
            $img_id        = $p->get_image_id() ?: get_post_thumbnail_id($pid);
            $out['img']    = $img_id ? wp_get_attachment_image_url($img_id, 'woocommerce_thumbnail') : '';
            return $out;
        };

        ob_start(); ?>
        <div class="ibb-wrapper" data-slots="<?php echo esc_attr($slots); ?>">
          <div class="ibb-slots">
            <?php for ($i=0; $i<$slots; $i++):
                $view   = $get_prefill_view($i);
                $filled = $view['filled'];
                $slotClass = $filled ? 'is-filled' : 'is-empty';

                // resolve size string if filled
                $size_text = '';
                if ($filled && !empty($prefilled[$i]['attr'])) {
                    foreach ($prefilled[$i]['attr'] as $k => $v) {
                        $lk = strtolower($k);
                        if (strpos($lk,'size') !== false || strpos($lk,'velicina') !== false || strpos($lk,'veličina') !== false) {
                            $size_text = strtoupper((string)$v);
                            break;
                        }
                    }
                }
                ?>
              <div class="ibb-slot-wrap">
                <div class="ibb-slot-header">Izberite majico <?php echo esc_html($i+1); ?> od <?php echo esc_html($slots); ?></div>
                <div class="ibb-slot <?php echo esc_attr($slotClass); ?>" data-index="<?php echo $i; ?>" tabindex="0" <?php if ($filled) echo 'data-product-id="'.esc_attr($view['pid']).'"'; ?>>
                  <div class="ibb-slot-thumb">
                    <?php if ($filled && $view['img']): ?>
                      <img src="<?php echo esc_url($view['img']); ?>" alt="">
                    <?php else: ?>
                      <span class="ibb-slot-plus" aria-hidden="true">+</span>
                    <?php endif; ?>
                  </div>
                  <div class="ibb-slot-info">
                    <span class="ibb-slot-attr"><?php echo $filled ? esc_html($size_text) : esc_html__('Dodaj majicu','ibb'); ?></span>
                    <span class="ibb-slot-price" hidden></span>
                  </div>
                  <?php if ($filled): ?>
                    <button type="button" class="ibb-slot-remove" aria-label="<?php esc_attr_e('Remove','ibb'); ?>">×</button>
                  <?php endif; ?>
                </div>
              </div>
            <?php endfor; ?>
          </div>
          <input type="hidden" class="ibb-cart-data" name="ibb_cart_data" value="[]">
        </div>

        <!-- Modal -->
        <div class="ibb-modal" aria-hidden="true">
          <div class="ibb-modal__box" role="dialog" aria-modal="true" aria-label="Bundle builder">
          
          
            <div class="ibb-modal__head">
                <!--<button type="button" class="ibb-modal__close-mobile" aria-label="Zavřít">⌄</button>-->

              <div class="ibb-steps-nav">
                <button type="button" class="ibb-nav ibb-prev" aria-label="Previous step">‹</button>
                <div class="ibb-steps" role="tablist" aria-label="Slots"></div>
                <button type="button" class="ibb-nav ibb-next" aria-label="Next step">›</button>
              </div>
              <button type="button" class="ibb-modal__close" aria-label="Close">×</button>
              
              
            <div class="ibb-titlebar">
              <h2 class="ibb-heading">Odaberi <span class="ibb-step-num">1</span> majicu</h2>
              <p class="ibb-sub">Dodajte 4 majice i dobit ćete paket za 39,99€</p>
            </div>
              
              
              
            </div>
            

          

            <div class="ibb-modal__body">
              <div class="ibb-grid">
                <?php foreach ($cards as $c): ?>
                  <div class="ibb-card" data-id="<?php echo esc_attr($c['id']); ?>" data-type="<?php echo esc_attr($c['type']); ?>">
                    <img src="<?php echo esc_url($c['img']); ?>" alt="<?php echo esc_attr($c['title']); ?>">
                    <div class="ibb-card-body">
                      <div class="ibb-card-title"><?php echo esc_html($c['title']); ?></div>

                      <?php if ($c['type'] === 'variable' && !empty($c['attrs'])): ?>
                        <?php foreach ($c['attrs'] as $a): ?>
                          <label class="ibb-label"><?php echo esc_html($a['label']); ?></label>
                          <select class="ibb-attr"
                                  data-taxonomy="<?php echo esc_attr($a['norm']); ?>"
                                  data-taxonomy-raw="<?php echo esc_attr('attribute_' . $a['norm']); ?>">
                            <option value=""><?php echo esc_html__('Vyberte variantu', 'ibb'); ?></option>
                            <?php foreach ($a['opts'] as $o): ?>
                              <option value="<?php echo esc_attr($o['value']); ?>"><?php echo esc_html($o['label']); ?></option>
                            <?php endforeach; ?>
                          </select>
                        <?php endforeach; ?>
                      <?php endif; ?>

                      <button type="button" class="ibb-add"><?php esc_html_e('Dodaj u paket','ibb'); ?></button>
                      <div class="ibb-msg" aria-live="polite"></div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* -------------------------------------------------
     * AJAX: variation resolver (unchanged)
     * ------------------------------------------------*/
    public function ajax_find_variation() {
        check_ajax_referer('ibb', 'nonce');

        $product_id = absint($_POST['product_id'] ?? 0);
        $attrs_in   = isset($_POST['attributes']) ? (array) $_POST['attributes'] : [];

        $product = wc_get_product($product_id);
        if (!$product || !$product->is_type('variable')) {
            wp_send_json_error(['message' => 'Invalid product']);
        }

        $attrs = [];
        foreach ($attrs_in as $k => $v) {
            $k = sanitize_title($k);
            $attrs['attribute_' . $k] = wc_clean($v);
        }

        $ds = new WC_Product_Data_Store_CPT();
        $variation_id = $ds->find_matching_product_variation($product, $attrs);

        if (!$variation_id) {
            wp_send_json_error(['message' => 'This option is unavailable.']);
        }

        $vp = wc_get_product($variation_id);
        wp_send_json_success([
            'variation_id' => $variation_id,
            'price'        => $vp ? $vp->get_price_html() : '',
        ]);
    }

    /* -------------------------------------------------
     * Helpers: parse & aggregate simple meta
     * ------------------------------------------------*/
    private function parse_slots_from_post() : array {
        if (empty($_POST['ibb_cart_data'])) return [];
        $raw   = wp_unslash($_POST['ibb_cart_data']);
        $slots = json_decode($raw, true);
        return is_array($slots) ? $slots : [];
    }

    private function mb_lower($str) {
        if (function_exists('mb_strtolower')) return mb_strtolower($str, 'UTF-8');
        return strtolower($str);
    }

    private function looks_like_color_key($key) : bool {
        $k = $this->mb_lower($key);
        return (strpos($k, 'color') !== false) || (strpos($k, 'boja') !== false) || (strpos($k, 'kolor') !== false);
    }

    private function looks_like_size_key($key) : bool {
        $k = $this->mb_lower($key);
        return (strpos($k, 'size') !== false) || (strpos($k, 'velicina') !== false) || (strpos($k, 'veličina') !== false);
    }

    private function aggregate_colors_and_sizes(array $slots) : array {
        $colors = [];
        $sizes  = [];

        foreach ($slots as $slot) {
            if (empty($slot['product_id'])) continue;
            if (empty($slot['attr']) || !is_array($slot['attr'])) continue;

            foreach ($slot['attr'] as $k => $v) {
                $val = (string) $v;
                if ($val === '') continue;

                if ($this->looks_like_color_key($k)) {
                    $colors[$val] = ($colors[$val] ?? 0) + 1;
                }
                if ($this->looks_like_size_key($k)) {
                    $sizes[strtoupper($val)] = ($sizes[strtoupper($val)] ?? 0) + 1;
                }
            }
        }
        return [$colors, $sizes];
    }

    /* -------------------------------------------------
     * Cart & Order: simple meta saving & display
     * ------------------------------------------------*/

    public function hook_add_cart_item_data($cart_item_data, $product_id, $variation_id) {
        $slots = $this->parse_slots_from_post();
        if (!$slots) return $cart_item_data;

        list($colors, $sizes) = $this->aggregate_colors_and_sizes($slots);

        $cart_item_data['bundle_colors'] = $colors;
        $cart_item_data['bundle_sizes']  = $sizes;

        $cart_item_data['_ibb_slots_json'] = wp_json_encode($slots);

        $cart_item_data['ibb_unique_key'] = md5( wp_json_encode([$colors,$sizes]) . '|' . microtime(true) . '|' . wp_rand() );

        return $cart_item_data;
    }

    public function hook_display_item_data($item_data, $cart_item) {
        if (!empty($cart_item['bundle_colors']) && is_array($cart_item['bundle_colors'])) {
            foreach ($cart_item['bundle_colors'] as $color => $qty) {
                $label = ucfirst($color);
                $item_data[] = [
                    'name'  => $label,
                    'value' => sprintf('%d %s', (int)$qty, __('kom', 'ibb')),
                ];
            }
        }

        if (!empty($cart_item['bundle_sizes']) && is_array($cart_item['bundle_sizes'])) {
            foreach ($cart_item['bundle_sizes'] as $size => $qty) {
                $label = sprintf('%s %s', __('Veličina', 'ibb'), strtoupper($size));
                $item_data[] = [
                    'name'  => $label,
                    'value' => sprintf('%d %s', (int)$qty, __('kom', 'ibb')),
                ];
            }
        }

        return $item_data;
    }

    public function hook_order_item_meta($item, $cart_item_key, $values, $order) {
        if (!empty($values['bundle_colors']) && is_array($values['bundle_colors'])) {
            foreach ($values['bundle_colors'] as $color => $qty) {
                $item->add_meta_data(ucfirst($color), sprintf('%d %s', (int)$qty, __('kom', 'ibb')), true);
            }
        }
        if (!empty($values['bundle_sizes']) && is_array($values['bundle_sizes'])) {
            foreach ($values['bundle_sizes'] as $size => $qty) {
                $item->add_meta_data(sprintf('%s %s', __('Veličina','ibb'), strtoupper($size)), sprintf('%d %s', (int)$qty, __('kom','ibb')), true);
            }
        }
        if (!empty($values['_ibb_slots_json'])) {
            $item->add_meta_data('_ibb_slots_json', $values['_ibb_slots_json'], true);
        }
    }
}

new IBB_Plugin_SimpleMeta();
